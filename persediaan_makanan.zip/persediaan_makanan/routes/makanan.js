const express = require("express");
const router = express.Router();
const Makanan = require("../models/makananModel");

/* READ */
router.get("/", (req,res)=>{
  Makanan.getAll((err,rows)=>{
    if(err) throw err;
    res.render("index",{data:rows});
  });
});

/* CREATE */
router.post("/add",(req,res)=>{

  const data = {
    nama:req.body.nama,
    stok:req.body.stok,
    harga:req.body.harga
  };

  // Percabangan
  if(data.stok < 0){
    console.log("Stok tidak valid");
    res.redirect("/");
  }else{
    Makanan.tambah(data,()=>{
      res.redirect("/");
    });
  }
});

/* DELETE */
router.get("/delete/:id",(req,res)=>{
  Makanan.hapus(req.params.id,()=>{
    res.redirect("/");
  });
});

module.exports = router;