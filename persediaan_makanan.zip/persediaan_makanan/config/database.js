const mysql = require("mysql2");

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "persediaan_makanan"
});

db.connect((err)=>{
  if(err){
    console.log("Database gagal konek");
    return;
  }
  console.log("Database Connected!");
});

module.exports = db;