const express = require("express");
const bodyParser = require("body-parser");

const app = express();

/* setting */
app.set("view engine","ejs");
app.use(bodyParser.urlencoded({extended:false}));
app.use(express.static("public"));

/* routes */
const makananRoutes = require("./routes/makanan");
app.use("/", makananRoutes);

/* server */
app.listen(3000, ()=>{
  console.log("Server running http://localhost:3000");
});